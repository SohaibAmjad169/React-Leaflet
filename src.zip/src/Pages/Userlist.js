import React, { useState } from 'react';
import ListData from './Listdata';

const Userlist = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewType, setViewType] = useState('list'); 
  const filteredTableData = ListData.filter(item =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleView = (type) => {
    setViewType(type);
  };

  return (
    <>
      <div className='row'>
        <div className='col-md-2'></div>
        <div className='col-md-8 mt-5 aa'>
          <div className='tab-btn'>
            <button onClick={() => toggleView('list')}>List</button>
            <button onClick={() => toggleView('grid')}>Grid</button>
            <span>
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </span>
          </div>
          <hr />
          {viewType === 'list' ? (
            <table className='table table-striped mt-2'>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                </tr>
              </thead>
              <tbody>
                {searchQuery === '' ? (
                  ListData.map((val, i) => (
                    <tr key={val.id}>
                      <td>{i + 1}</td>
                      <td>{val.name}</td>
                      <td>{val.email}</td>
                      <td>{val.role}</td>
                    </tr>
                  ))
                ) : filteredTableData.length === 0 ? (
                  <tr>
                    <td colSpan="4">No data found</td>
                  </tr>
                ) : (
                  filteredTableData.map((val, i) => (
                    <tr key={val.id}>
                      <td>{i + 1}</td>
                      <td>{val.name}</td>
                      <td>{val.email}</td>
                      <td>{val.role}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          ) : (
           
            <GridComponent data={searchQuery === '' ? ListData : filteredTableData} />
          )}
        </div>
        <div className='col-md-2'></div>
      </div>
    </>
  );
};

const GridComponent = ({ data }) => {
  return (
    <div className="grid-container">
      {data.map((val, i) => (
        <div key={val.id} className="grid-item">
          <p>Name : {val.name}</p>
          <p>Email : {val.email}</p>
          <p>Role : {val.role}</p>
        </div>
      ))}
    </div>
  );
};

export default Userlist;
