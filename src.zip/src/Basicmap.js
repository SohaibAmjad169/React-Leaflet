import React, { useRef, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup,FeatureGroup } from 'react-leaflet';
import OsmProvider from './OsmProvider';
import './Pages/Pages.css';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { EditControl } from 'react-leaflet-draw';
import "leaflet-draw/dist/leaflet.draw.css"

delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl:"https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.3.1/images/marker-icon.png",
  iconUrl:"https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.3.1/images/marker-icon.png",
  shadowUrl:"https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.3.1/images/marker-shadow.png",
})

const markerIcon = new L.Icon({
  iconUrl: require('../src/Images/icon.png'), // Correct the path to your icon
  iconSize: [25, 30],
  iconAnchor:[17,46],
  popupAnchor:[0,-46]
});

const Basicmap = () => {
  const [center, setCenter] = useState({ lat: 13.084622, lng: 80.248357 });
  const Zoom_LEVEL = 9;
  const mapRef = useRef();
  const _created = e => console.log(e);


  return (
    <div>
      <MapContainer center={center} zoom={Zoom_LEVEL} ref={mapRef}>

      <FeatureGroup>
          <EditControl position="topleft"/>
        </FeatureGroup>

        <TileLayer url={OsmProvider.maptiler.url} attribution={OsmProvider.maptiler.attribution} />

        <Marker position={[13.084622, 80.248357]} icon={markerIcon}>
          <Popup>
            <p>First Marker</p>
          </Popup>
        </Marker>
      </MapContainer>
    </div>
  );
};

export default Basicmap;
