import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap'
import Sidenav from './components/Sidenav';
import Home from './Pages/Home';
import Userlist from './Pages/Userlist';
import { Route,Routes } from 'react-router-dom';
import Basicmap from './Basicmap';


function App() {
  return (
  <>
  <Sidenav/>
  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/userlist" element={<Userlist />} />
    <Route path='/maps' element={<Basicmap/>}/>
  </Routes>
  
  </>
  );
}

export default App;
