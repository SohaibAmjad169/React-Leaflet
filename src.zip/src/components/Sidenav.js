import React, { useState } from 'react';
import './Sidenav.css';
import { FaBars, FaHome } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const Sidenav = () => {
  const [show, setShow] = useState(false);

  return (
    <>
      <div>
        <div className='sidebar'>
          <FaBars className='side-logo' onClick={() => setShow(!show)} />
          {show && (
            <div className='sidebar-side'>
              <ul className='sidebar-item'>
                <Link to="/" className='li'>
                  <FaHome /> <h2>Home</h2>
                </Link>
                <Link to="/userlist" className='li'>
                  <FaHome />
                  <h2>Dashboard</h2>
                </Link>
                <Link to="/userlist" className='li'>
                  <FaHome />
                  <h2>Dashboard</h2>
                </Link>
                <Link to="/userlist" className='li'>
                  <FaHome />
                  <h2>Dashboard</h2>
                </Link>
              </ul>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Sidenav;
