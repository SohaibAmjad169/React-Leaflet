const ListData = [
  {
    name:'habib',
    email:'habib@gmail.com',
    role:'admin'
  },
  {
    name:'Sohaib',
    email:'sohaib@gmail.com',
    role:'user'
  },
  {
    name:'zunair',
    email:'zunair@gmail.com',
    role:'admin'
  }
]

export default ListData;