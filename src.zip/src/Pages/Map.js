import React from 'react';
import { Map , TileLayer} from 'react-leaflet'

const Map1 = () => {
  return (
    <div>
        <Map>

        </Map>
    </div>
  )
}

export default Map1